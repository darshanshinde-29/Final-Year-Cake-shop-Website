from django.contrib import admin
from .models import *
# Register your models here.


@admin.register(Cake)
class CakeAdmin(admin.ModelAdmin):
    list_display = ("id", "name", "category", "veg_nonveg", "price")
    search_fields = ("name", "category")
    list_filter = ("category", "veg_nonveg")
