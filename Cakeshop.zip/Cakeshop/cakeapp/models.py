
# Create your models here.
# accounts/models.py
from django.db import models
from django.contrib.auth.models import User
from django.utils.timezone import now, timedelta

class EmailOTP2(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    otp_code = models.CharField(max_length=6)
    created_at = models.DateTimeField(auto_now_add=True)

    def is_valid(self):
        return now() < self.created_at + timedelta(minutes=5)  # 5 min expiry

class Cake(models.Model):
    name = models.CharField(max_length=1000)
    description = models.TextField(max_length=2000, blank=True)
    category = models.CharField(max_length=1000)
    veg_nonveg = models.CharField(max_length=10, choices=[
        ('veg', 'Vegetarian'),
        ('nonveg', 'Non-Vegetarian'),
    ])
    price = models.DecimalField(max_digits=8, decimal_places=2)
    cake_image = models.ImageField(upload_to='cakes/', blank=True, null=True)
