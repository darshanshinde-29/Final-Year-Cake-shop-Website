from django.shortcuts import render , redirect
from django.contrib import messages
from django.contrib.auth.models import User
from .utils import send_otp_email
from .models import *
from .forms import CustomUserCreationForm  # import custom form
from django.contrib import messages
# Create your views here.

def home(req):
    if req.user.is_authenticated:


        categories = Cake.objects.values_list("category", flat=True).distinct()
        cakes_by_category = {}
        for category in categories:
            cakes_by_category[category] = Cake.objects.filter(category=category)
    
        return render(req, "landing_user.html", {"cakes_by_category": cakes_by_category})
        # return render(req, "landing_user.html")  # template for logged-in users
    else:
        return redirect('/')  # template for visitors

# def request_otp(request):
#     if request.method == "POST":
#         email = request.POST.get("email")
#         try:
#             user = User.objects.get(email=email)
#             send_otp_email(user)
#             messages.success(request, "OTP sent to your email.")
#             return redirect("verify_otp", user_id=user.id)
#         except User.DoesNotExist:
#             messages.error(request, "No user with this email.")
#     return render(request, "request_otp.html")


# def verify_otp(request, user_id):
#     if request.method == "POST":
#         otp = request.POST.get("otp")
#         user = User.objects.get(id=user_id)
#         try:
#             otp_obj = EmailOTP2.objects.filter(user=user).latest("created_at")
#             if otp_obj.otp_code == otp and otp_obj.is_valid():
#                 messages.success(request, "OTP verified successfully ✅")
#                 # you can log the user in here
#                 return redirect("home")
#             else:
#                 messages.error(request, "Invalid or expired OTP ❌")
#         except EmailOTP2.DoesNotExist:
#             messages.error(request, "No OTP found.")
#     return render(request, "verify_otp.html")

def about(req):
    return render(req, "About.html")


def contact(req):
    return render(req, "Contact.html")


def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Account created successfully! You can now log in.")
            return redirect('login')  # redirect after register
    else:
        form = CustomUserCreationForm()
    return render(request, 'register.html', {'form': form})
