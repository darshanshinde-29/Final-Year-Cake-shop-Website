from django.shortcuts import render, HttpResponse

brand = "CakeZone"

def landing(req):
    return render(req, "landing.html", {'brand':brand})

